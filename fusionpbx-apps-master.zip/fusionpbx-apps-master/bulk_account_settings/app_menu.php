<?php

$apps[$x]['menu'][0]['title']['en-us'] = "Bulk Account Settings";
$apps[$x]['menu'][0]['uuid'] = "cdfd8c74-d086-4a49-a7e6-3b702953d554";
$apps[$x]['menu'][0]['parent_uuid'] = "594d99c5-6128-9c88-ca35-4b33392cec0f";
$apps[$x]['menu'][0]['category'] = "internal";
$apps[$x]['menu'][0]['path'] = "/app/bulk_account_settings/bulk_account_settings.php";
$apps[$x]['menu'][0]['groups'][] = "superadmin";

?>
