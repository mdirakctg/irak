<?php

	$y = 0;
	$apps[$x]['menu'][$y]['title']['en-us'] = 'Invoices';
	$apps[$x]['menu'][$y]['title']['es-mx'] = '';
	$apps[$x]['menu'][$y]['title']['de'] = '';
	$apps[$x]['menu'][$y]['title']['de-ch'] = '';
	$apps[$x]['menu'][$y]['title']['de-at'] = '';
	$apps[$x]['menu'][$y]['title']['fr'] = '';
	$apps[$x]['menu'][$y]['title']['fr-ca'] = '';
	$apps[$x]['menu'][$y]['title']['fr-ch'] = '';
	$apps[$x]['menu'][$y]['title']['pt-pt'] = '';
	$apps[$x]['menu'][$y]['title']['pt-br'] = '';
	$apps[$x]['menu'][$y]['uuid'] = '6ebe753b-0f83-dc34-1c0b-51df2c6f0c3b';
	$apps[$x]['menu'][$y]['parent_uuid'] = 'fd29e39c-c936-f5fc-8e2b-611681b266b5';
	$apps[$x]['menu'][$y]['category'] = 'internal';
	$apps[$x]['menu'][$y]['path'] = '/app/invoices/invoices.php';
	//$apps[$x]['menu'][$y]['groups'][] = 'user';
	//$apps[$x]['menu'][$y]['groups'][] = 'admin';
	$apps[$x]['menu'][$y]['groups'][] = 'superadmin';

?>