<?php

$apps[$x]['menu'][0]['title']['en-us'] = "Hot Desking";
$apps[$x]['menu'][0]['title']['es-cl'] = "Escritorio remoto";
$apps[$x]['menu'][0]['title']['es-mx'] = "Escritorio remoto";
$apps[$x]['menu'][0]['title']['fr-fr'] = "Itinérance";
$apps[$x]['menu'][0]['title']['fr-ca'] = "Bureau Lointain";
$apps[$x]['menu'][0]['title']['pt-pt'] = "Escritório Remoto";
$apps[$x]['menu'][0]['title']['pt-br'] = "Escritório remoto";
$apps[$x]['menu'][0]['title']['sv-se'] = "Hot Desking ";
$apps[$x]['menu'][0]['title']['pl'] = "Gorące biurka";
$apps[$x]['menu'][0]['title']['de-at'] = "Mobiler Arbeitsplatz";
$apps[$x]['menu'][0]['uuid'] = "baa57691-37d4-4c7d-b227-f2929202b480";
$apps[$x]['menu'][0]['parent_uuid'] = "fd29e39c-c936-f5fc-8e2b-611681b266b5";
$apps[$x]['menu'][0]['category'] = "internal";
$apps[$x]['menu'][0]['path'] = "/app/hot_desking/index.php";
$apps[$x]['menu'][0]['groups'][] = "superadmin";

?>