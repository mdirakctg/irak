This is considered deprecated in favor of the new hot desking.
