<?php

	$apps[$x]['menu'][0]['title']['en-us'] = 'Voicemail';
	$apps[$x]['menu'][0]['title']['es-mx'] = '';
	$apps[$x]['menu'][0]['title']['de-de'] = '';
	$apps[$x]['menu'][0]['title']['de-ch'] = '';
	$apps[$x]['menu'][0]['title']['de-at'] = '';
	$apps[$x]['menu'][0]['title']['fr-fr'] = '';
	$apps[$x]['menu'][0]['title']['fr-ca'] = '';
	$apps[$x]['menu'][0]['title']['fr-ch'] = '';
	$apps[$x]['menu'][0]['title']['pt-pt'] = 'Correio de Voz';
	$apps[$x]['menu'][0]['title']['pt-br'] = '';
	$apps[$x]['menu'][0]['uuid'] = 'e10d5672-0f82-6e5d-5022-a02ac8545198';
	$apps[$x]['menu'][0]['parent_uuid'] = 'fd29e39c-c936-f5fc-8e2b-611681b266b5';
	$apps[$x]['menu'][0]['category'] = 'internal';
	$apps[$x]['menu'][0]['path'] = '/app/voicemail_msgs/voicemail_msgs.php';
	$apps[$x]['menu'][0]['groups'][] = 'user';
	$apps[$x]['menu'][0]['groups'][] = 'admin';
	$apps[$x]['menu'][0]['groups'][] = 'superadmin';

?>