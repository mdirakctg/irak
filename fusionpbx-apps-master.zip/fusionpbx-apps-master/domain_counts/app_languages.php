<?php
$text['title-domain_counts']['en-us'] = "Domain Counts";

$text['header-domain_counts']['en-us'] = "Domain Counts";

$text['header-domain_counts_accountcodes']['en-us'] = "Accountcodes";

$text['description-domain_counts']['en-us'] = "Displays the number of items for each domain";

$text['description-domain_counts_accountcodes']['en-us'] = "Displays the number of extensions assigned to each domain accountcode.";

$text['label-domain_name']['en-us'] = "Domain Name";

$text['label-extensions']['en-us'] = "Extensions";

$text['label-users']['en-us'] = "Users";

$text['label-devices']['en-us'] = "Devices";

$text['label-destinations']['en-us'] = "Destinations";

$text['label-faxes']['en-us'] = "Faxes";

$text['label-ivrs']['en-us'] = "IVR's";

$text['label-voicemails']['en-us'] = "Voicemails";

$text['label-ring_groups']['en-us'] = "Ring Groups";

$text['label-cc_queues']['en-us'] = "CC Queues";

$text['label-contacts']['en-us'] = "Contacts";

$text['label-accountcodes']['en-us'] = "Accountcodes";

$text['label-accountcode']['en-us'] = "Accountcode";

$text['label-count']['en-us'] = "Extension Count";

$text['button-export']['en-us'] = "Export";

$text['title-domain_counts_accountcodes']['en-us'] = "Accountcodes";

?>
