<?php

$apps[$x]['menu'][0]['title']['en-us'] = "Domain Counts";
$apps[$x]['menu'][0]['title']['es-cl'] = "";
$apps[$x]['menu'][0]['title']['fr-fr'] = "";
$apps[$x]['menu'][0]['title']['pt-pt'] = "";
$apps[$x]['menu'][0]['title']['pt-br'] = "";
$apps[$x]['menu'][0]['title']['pl'] = "";
$apps[$x]['menu'][0]['title']['sv-se'] = "";
$apps[$x]['menu'][0]['title']['uk'] = "";
$apps[$x]['menu'][0]['title']['ro'] = "";
$apps[$x]['menu'][0]['title']['de-at'] = "";
$apps[$x]['menu'][0]['title']['ar-eg'] = "";
$apps[$x]['menu'][0]['title']['he'] = "";
$apps[$x]['menu'][0]['uuid'] = "8db32ec2-85dc-4782-a7b1-d0caf8a4e44e";
$apps[$x]['menu'][0]['parent_uuid'] = "0438b504-8613-7887-c420-c837ffb20cb1";
$apps[$x]['menu'][0]['category'] = "internal";
$apps[$x]['menu'][0]['path'] = "/app/domain_counts/domain_counts.php";
$apps[$x]['menu'][0]['groups'][] = "superadmin";
$apps[$x]['menu'][0]['groups'][] = "admin";

?>
