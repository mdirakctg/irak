<?php

	$apps[$x]['menu'][0]['title']['en-us'] = "Help";
	$apps[$x]['menu'][0]['uuid'] = "00e51f5c-0fb0-11e7-93ae-92361f002671";
	$apps[$x]['menu'][0]['parent_uuid'] = "";
	$apps[$x]['menu'][0]['category'] = "external";
	$apps[$x]['menu'][0]['icon'] = "glyphicon-question-sign";
	$apps[$x]['menu'][0]['path'] = "http://docs.fusionpbx.com";
	$apps[$x]['menu'][0]['order'] = "100";
	$apps[$x]['menu'][0]['groups'][] = "admin";
	$apps[$x]['menu'][0]['groups'][] = "superadmin";

?>
