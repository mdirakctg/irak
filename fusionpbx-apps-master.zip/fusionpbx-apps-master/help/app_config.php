<?php

	$apps[$x]['name'] = "Help";
	$apps[$x]['uuid'] = "9e0e39d0-4b5f-44ef-afc6-648ae121ab15";
	$apps[$x]['category'] = "Menu";
	$apps[$x]['subcategory'] = "";
	$apps[$x]['version'] = "1";
	$apps[$x]['license'] = "Mozilla Public License 1.1";
	$apps[$x]['url'] = "http://www.fusionpbx.com";
	$apps[$x]['description']['en-us'] = "Add help menu items";

?>
