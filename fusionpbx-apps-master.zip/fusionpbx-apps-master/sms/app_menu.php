<?php

$apps[$x]['menu'][0]['title']['en-us'] = "SMS";
$apps[$x]['menu'][0]['title']['es-cl'] = "";
$apps[$x]['menu'][0]['title']['es-mx'] = "";
$apps[$x]['menu'][0]['title']['fr-fr'] = "";
$apps[$x]['menu'][0]['title']['fr-ca'] = " ";
$apps[$x]['menu'][0]['title']['pt-pt'] = "";
$apps[$x]['menu'][0]['title']['pt-br'] = "";
$apps[$x]['menu'][0]['title']['pl'] = " ";
$apps[$x]['menu'][0]['title']['uk'] = "";
$apps[$x]['menu'][0]['title']['sv-se'] = "";
$apps[$x]['menu'][0]['title']['ro'] = "";
$apps[$x]['menu'][0]['title']['de-at'] = "";
$apps[$x]['menu'][0]['title']['ar-eg'] = "الأرقام الداخلية";
$apps[$x]['menu'][0]['title']['he'] = "";
$apps[$x]['menu'][0]['uuid'] = "d4278820-1d33-11e6-b6ba-3e1d05defe78";
$apps[$x]['menu'][0]['parent_uuid'] = "fd29e39c-c936-f5fc-8e2b-611681b266b5";
$apps[$x]['menu'][0]['category'] = "internal";
$apps[$x]['menu'][0]['path'] = "/app/sms/sms.php";
$apps[$x]['menu'][0]['groups'][] = "admin";
$apps[$x]['menu'][0]['groups'][] = "superadmin";

?>