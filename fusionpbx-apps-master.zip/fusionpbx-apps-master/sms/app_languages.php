<?php

$text['title-sms']['en-us'] = "SMS";
$text['title-sms']['es-cl'] = "";
$text['title-sms']['pt-pt'] = "";
$text['title-sms']['fr-fr'] = "";
$text['title-sms']['pt-br'] = "";
$text['title-sms']['pl'] = "";
$text['title-sms']['uk'] = "";
$text['title-sms']['sv-se'] = "";
$text['title-sms']['ro'] = "";
$text['title-sms']['de-at'] = "";
$text['title-sms']['ar-eg'] = "";
$text['title-sms']['he'] = "";

$text['header-sms']['en-us'] = "SMS";
$text['header-sms']['es-cl'] = "";
$text['header-sms']['pt-pt'] = "";
$text['header-sms']['fr-fr'] = "";
$text['header-sms']['pt-br'] = "";
$text['header-sms']['pl'] = "";
$text['header-sms']['uk'] = "";
$text['header-sms']['sv-se'] = "";
$text['header-sms']['ro'] = "";
$text['header-sms']['de-at'] = "";
$text['header-sms']['ar-eg'] = "";
$text['header-sms']['he'] = "";

$text['title-sms-edit']['en-us'] = "SMS";
$text['title-sms-edit']['es-cl'] = "";
$text['title-sms-edit']['pt-pt'] = "";
$text['title-sms-edit']['fr-fr'] = "";
$text['title-sms-edit']['pt-br'] = "";
$text['title-sms-edit']['pl'] = " ";
$text['title-sms-edit']['uk'] = "";
$text['title-sms-edit']['sv-se'] = "";
$text['title-sms-edit']['ro'] = "";
$text['title-sms-edit']['de-at'] = "";
$text['title-sms-edit']['ar-eg'] = "";
$text['title-sms-edit']['he'] = "";

$text['label-domain']['en-us'] = "Domain";
$text['label-domain']['es-cl'] = "";
$text['label-domain']['pt-pt'] = "";
$text['label-domain']['fr-fr'] = "";
$text['label-domain']['pt-br'] = "";
$text['label-domain']['pl'] = " ";
$text['label-domain']['uk'] = "";
$text['label-domain']['sv-se'] = "";
$text['label-domain']['ro'] = "";
$text['label-domain']['de-at'] = "";
$text['label-domain']['ar-eg'] = "";
$text['label-domain']['he'] = "";

$text['label-extension']['en-us'] = "Extension";
$text['label-extension']['es-cl'] = "";
$text['label-extension']['pt-pt'] = "";
$text['label-extension']['fr-fr'] = "";
$text['label-extension']['pt-br'] = "";
$text['label-extension']['pl'] = " ";
$text['label-extension']['uk'] = "";
$text['label-extension']['sv-se'] = "";
$text['label-extension']['ro'] = "";
$text['label-extension']['de-at'] = "";
$text['label-extension']['ar-eg'] = "";
$text['label-extension']['he'] = "";

$text['label-source']['en-us'] = "Source";
$text['label-source']['es-cl'] = "";
$text['label-source']['pt-pt'] = "";
$text['label-source']['fr-fr'] = "";
$text['label-source']['pt-br'] = "";
$text['label-source']['pl'] = " ";
$text['label-source']['uk'] = "";
$text['label-source']['sv-se'] = "";
$text['label-source']['ro'] = "";
$text['label-source']['de-at'] = "";
$text['label-source']['ar-eg'] = "";
$text['label-source']['he'] = "";

$text['label-destination']['en-us'] = "Destination";
$text['label-destination']['es-cl'] = "";
$text['label-destination']['pt-pt'] = "";
$text['label-destination']['fr-fr'] = "";
$text['label-destination']['pt-br'] = "";
$text['label-destination']['pl'] = " ";
$text['label-destination']['uk'] = "";
$text['label-destination']['sv-se'] = "";
$text['label-destination']['ro'] = "";
$text['label-destination']['de-at'] = "";
$text['label-destination']['ar-eg'] = "";
$text['label-destination']['he'] = "";

$text['label-start']['en-us'] = "Time Stamp";
$text['label-start']['es-cl'] = "";
$text['label-start']['pt-pt'] = "";
$text['label-start']['fr-fr'] = "";
$text['label-start']['pt-br'] = "";
$text['label-start']['pl'] = " ";
$text['label-start']['uk'] = "";
$text['label-start']['sv-se'] = "";
$text['label-start']['ro'] = "";
$text['label-start']['de-at'] = "";
$text['label-start']['ar-eg'] = "";
$text['label-start']['he'] = "";

$text['label-carrier']['en-us'] = "Carrier";
$text['label-carrier']['es-cl'] = "";
$text['label-carrier']['pt-pt'] = "";
$text['label-carrier']['fr-fr'] = "";
$text['label-carrier']['pt-br'] = "";
$text['label-carrier']['pl'] = " ";
$text['label-carrier']['uk'] = "";
$text['label-carrier']['sv-se'] = "";
$text['label-carrier']['ro'] = "";
$text['label-carrier']['de-at'] = "";
$text['label-carrier']['ar-eg'] = "";
$text['label-carrier']['he'] = "";

$text['label-message']['en-us'] = "Message";
$text['label-message']['es-cl'] = "";
$text['label-message']['pt-pt'] = "";
$text['label-message']['fr-fr'] = "";
$text['label-message']['pt-br'] = "";
$text['label-message']['pl'] = " ";
$text['label-message']['uk'] = "";
$text['label-message']['sv-se'] = "";
$text['label-message']['ro'] = "";
$text['label-message']['de-at'] = "";
$text['label-message']['ar-eg'] = "";
$text['label-message']['he'] = "";

$text['button-mdr']['en-us'] = "MDRs";
$text['button-mdr']['es-cl'] = "";
$text['button-mdr']['pt-pt'] = "";
$text['button-mdr']['fr-fr'] = "";
$text['button-mdr']['pt-br'] = "";
$text['button-mdr']['pl'] = " ";
$text['button-mdr']['uk'] = "";
$text['button-mdr']['sv-se'] = "";
$text['button-mdr']['ro'] = "";
$text['button-mdr']['de-at'] = "";
$text['button-mdr']['ar-eg'] = "";
$text['button-mdr']['he'] = "";

?>