CREATE TABLE v_fifo_agent_profiles (fifo_agent_profile_id INTEGER PRIMARY KEY, v_id NUMBER, profile_name TEXT, profile_desc TEXT);
