CREATE TABLE v_fifo_agent_profile_members (fifo_agent_profile_member_id INTEGER PRIMARY KEY, v_id NUMBER, fifo_agent_profile_id NUMBER, fifo_name TEXT, agent_priority TEXT, agent_username TEXT);
