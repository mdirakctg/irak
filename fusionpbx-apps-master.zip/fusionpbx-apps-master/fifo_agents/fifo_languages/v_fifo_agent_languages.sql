CREATE TABLE v_fifo_agent_languages (fifo_agent_language_id INTEGER PRIMARY KEY, v_id TEXT, username TEXT, language TEXT, proficiency TEXT);
