CREATE TABLE v_fifo_agent_status_logs (fifo_agent_status_log_id INTEGER PRIMARY KEY, v_id NUMBER, username TEXT, agent_status TEXT, uuid TEXT, add_date TEXT)
