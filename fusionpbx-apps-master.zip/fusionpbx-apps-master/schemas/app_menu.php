<?php

	$apps[$x]['menu'][0]['title']['en-us'] = "Schemas";
	$apps[$x]['menu'][0]['title']['es-cl'] = "Esquemas";
	$apps[$x]['menu'][0]['title']['es-mx'] = "";
	$apps[$x]['menu'][0]['title']['de-de'] = "";
	$apps[$x]['menu'][0]['title']['de-ch'] = "";
	$apps[$x]['menu'][0]['title']['de-at'] = "";
	$apps[$x]['menu'][0]['title']['fr-fr'] = "Schémas";
	$apps[$x]['menu'][0]['title']['fr-ca'] = "";
	$apps[$x]['menu'][0]['title']['fr-ch'] = "";
	$apps[$x]['menu'][0]['title']['pt-pt'] = "Tabelas";
	$apps[$x]['menu'][0]['title']['pt-br'] = "";
	$apps[$x]['menu'][0]['uuid'] = "6be94b46-2126-947f-2365-0bea23651a6b";
	$apps[$x]['menu'][0]['parent_uuid'] = "fd29e39c-c936-f5fc-8e2b-611681b266b5";
	$apps[$x]['menu'][0]['category'] = "internal";
	$apps[$x]['menu'][0]['path'] = "/app/schemas/schemas.php";
	$apps[$x]['menu'][0]['groups'][] = "superadmin";

?>