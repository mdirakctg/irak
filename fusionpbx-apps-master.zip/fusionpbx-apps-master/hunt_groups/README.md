This feature is deprecated and likely to be removed in the future.
