<?php

	$apps[$x]['menu'][0]['title']['en-us'] = 'PHP Service';
	$apps[$x]['menu'][0]['title']['es-mx'] = '';
	$apps[$x]['menu'][0]['title']['de-de'] = '';
	$apps[$x]['menu'][0]['title']['de-ch'] = '';
	$apps[$x]['menu'][0]['title']['de-at'] = '';
	$apps[$x]['menu'][0]['title']['fr-fr'] = '';
	$apps[$x]['menu'][0]['title']['fr-ca'] = '';
	$apps[$x]['menu'][0]['title']['fr-ch'] = '';
	$apps[$x]['menu'][0]['title']['pt-pt'] = 'Servi�o PHP';
	$apps[$x]['menu'][0]['title']['pt-br'] = '';
	$apps[$x]['menu'][0]['uuid'] = 'a8196e2f-5f60-e723-aa3e-83ed76b2ef09';
	$apps[$x]['menu'][0]['parent_uuid'] = '594d99c5-6128-9c88-ca35-4b33392cec0f';
	$apps[$x]['menu'][0]['category'] = 'internal';
	$apps[$x]['menu'][0]['path'] = '/app/php_service/v_php_service.php';
	$apps[$x]['menu'][0]['groups'][] = 'superadmin';

?>