<?php

$apps[$x]['menu'][0]['title']['en-us'] = "Content Manager";
$apps[$x]['menu'][0]['title']['es-cl'] = "Gestor de Contenido";
$apps[$x]['menu'][0]['title']['es-mx'] = "Administrador de Contenido";
$apps[$x]['menu'][0]['title']['fr-fr'] = "Contenu";
$apps[$x]['menu'][0]['title']['fr-ca'] = "Administrateur";
$apps[$x]['menu'][0]['title']['pt-pt'] = "Gestor de Conteúdo";
$apps[$x]['menu'][0]['title']['pt-br'] = "Gerenciador de Conteúdo";
$apps[$x]['menu'][0]['title']['he'] = "מנהל תוכן";
$apps[$x]['menu'][0]['title']['pl'] = "Menedżer zawartości";
$apps[$x]['menu'][0]['title']['uk'] = "Менеджер вмісту";
$apps[$x]['menu'][0]['title']['sv-se'] = "Innehålls Inställningar";
$apps[$x]['menu'][0]['uuid'] = "90397352-395c-40f6-2087-887144abc06d";
$apps[$x]['menu'][0]['parent_uuid'] = "02194288-6d56-6d3e-0b1a-d53a2bc10788";
$apps[$x]['menu'][0]['category'] = "internal";
$apps[$x]['menu'][0]['path'] = "/app/content/rsslist.php";
$apps[$x]['menu'][0]['groups'][] = "admin";
$apps[$x]['menu'][0]['groups'][] = "superadmin";

?>