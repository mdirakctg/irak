<?php

$apps[$x]['menu'][0]['title']['en-us'] = "BDR Management";
$apps[$x]['menu'][0]['title']['es-cl'] = "";
$apps[$x]['menu'][0]['title']['fr-fr'] = "";
$apps[$x]['menu'][0]['title']['pt-pt'] = "";
$apps[$x]['menu'][0]['title']['pt-br'] = "";
$apps[$x]['menu'][0]['title']['pl'] = "";
$apps[$x]['menu'][0]['title']['sv-se'] = "";
$apps[$x]['menu'][0]['title']['uk'] = "";
$apps[$x]['menu'][0]['title']['ro'] = "";
$apps[$x]['menu'][0]['title']['de-at'] = "";
$apps[$x]['menu'][0]['title']['ar-eg'] = "";
$apps[$x]['menu'][0]['title']['he'] = "";
$apps[$x]['menu'][0]['uuid'] = "7ed61deb-14dd-49f6-940d-6cf2023f8481";
$apps[$x]['menu'][0]['parent_uuid'] = "594d99c5-6128-9c88-ca35-4b33392cec0f";
$apps[$x]['menu'][0]['category'] = "internal";
$apps[$x]['menu'][0]['path'] = "/app/bdr/bdr.php";
$apps[$x]['menu'][0]['groups'][] = "superadmin";

?>