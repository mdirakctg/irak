WARNING: currently broken and not secure enough. Needs to be rewritten.
