<?php

	$apps[$x]['menu'][0]['title']['en-us'] = 'Sign Up';
	$apps[$x]['menu'][0]['title']['es-mx'] = 'Inscribirse';
	$apps[$x]['menu'][0]['title']['de-de'] = '';
	$apps[$x]['menu'][0]['title']['de-ch'] = '';
	$apps[$x]['menu'][0]['title']['de-at'] = '';
	$apps[$x]['menu'][0]['title']['fr-fr'] = '';
	$apps[$x]['menu'][0]['title']['fr-ca'] = '';
	$apps[$x]['menu'][0]['title']['fr-ch'] = '';
	$apps[$x]['menu'][0]['title']['pt-pt'] = 'Iniciar';
	$apps[$x]['menu'][0]['title']['pt-br'] = '';
	$apps[$x]['menu'][0]['uuid'] = 'a8f49f02-9bfb-65ff-4cd3-85dc3354e4c1';
	$apps[$x]['menu'][0]['parent_uuid'] = '';
	$apps[$x]['menu'][0]['category'] = 'internal';
	$apps[$x]['menu'][0]['path'] = '/app/users/usersupdate.php';
	$apps[$x]['menu'][0]['groups'][] = 'disabled';

?>