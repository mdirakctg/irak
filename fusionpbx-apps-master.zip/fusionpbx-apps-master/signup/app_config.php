<?php

	//application details
		$apps[$x]['name'] = "Sign Up";
		$apps[$x]['uuid'] = 'd308e9c6-d907-5ba7-b3be-6d3e09cf01aa';
		$apps[$x]['category'] = 'System';
		$apps[$x]['subcategory'] = '';
		$apps[$x]['version'] = '';
		$apps[$x]['license'] = 'Mozilla Public License 1.1';
		$apps[$x]['url'] = 'http://www.fusionpbx.com';
		$apps[$x]['description']['en-us'] = 'Allows customers on the internet to signup for a user account.';
		$apps[$x]['description']['es-mx'] = 'Permite a los clientes crear una cuenta desde Internet';
		$apps[$x]['description']['de-de'] = '';
		$apps[$x]['description']['de-ch'] = '';
		$apps[$x]['description']['de-at'] = '';
		$apps[$x]['description']['fr-fr'] = '';
		$apps[$x]['description']['fr-ca'] = '';
		$apps[$x]['description']['fr-ch'] = '';
		$apps[$x]['description']['pt-pt'] = 'Permite aos clientes na internet para para criar uma conta de utilizador.';
		$apps[$x]['description']['pt-br'] = '';

	//permission details
		$apps[$x]['permissions'][0]['name'] = 'signup';

?>
