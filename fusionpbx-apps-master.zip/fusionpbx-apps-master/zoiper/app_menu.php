<?php

$apps[$x]['menu'][0]['title']['en-us'] = "Zoiper";
$apps[$x]['menu'][0]['title']['es-cl'] = "";
$apps[$x]['menu'][0]['title']['fr-fr'] = "";
$apps[$x]['menu'][0]['title']['pt-pt'] = "";
$apps[$x]['menu'][0]['title']['pt-br'] = "";
$apps[$x]['menu'][0]['title']['pl'] = "";
$apps[$x]['menu'][0]['title']['he'] = "";
$apps[$x]['menu'][0]['title']['uk'] = "";
$apps[$x]['menu'][0]['title']['sv-se'] = "";
$apps[$x]['menu'][0]['title']['de-at'] = "";
$apps[$x]['menu'][0]['title']['ro'] = "";
$apps[$x]['menu'][0]['title']['ar-eg'] = "";
$apps[$x]['menu'][0]['uuid'] = "fe8a5b30-834f-4eeb-8462-494ad6034588";
$apps[$x]['menu'][0]['parent_uuid'] = "fd29e39c-c936-f5fc-8e2b-611681b266b5";
$apps[$x]['menu'][0]['category'] = "internal";
$apps[$x]['menu'][0]['path'] = "/app/zoiper/zoiper.php";
$apps[$x]['menu'][0]['groups'][] = "user";
$apps[$x]['menu'][0]['groups'][] = "admin";
$apps[$x]['menu'][0]['groups'][] = "superadmin";

?>
