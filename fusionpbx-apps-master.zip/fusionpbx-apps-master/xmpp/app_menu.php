<?php

$apps[$x]['menu'][0]['title']['en-us'] = "XMPP Manager";
$apps[$x]['menu'][0]['title']['es-cl'] = "Gestor XMPP";
$apps[$x]['menu'][0]['title']['fr-fr'] = "Gestion XMPP";
$apps[$x]['menu'][0]['title']['pt-pt'] = "Gestor XMPP";
$apps[$x]['menu'][0]['title']['pt-br'] = "Gerenciador XMPP";
$apps[$x]['menu'][0]['title']['pl'] = "Menedżer XMPP";
$apps[$x]['menu'][0]['title']['sv-se'] = "XMPP Inställningar";
$apps[$x]['menu'][0]['uuid'] = "1808365b-0f7c-7555-89d0-31b3d9a75abb";
$apps[$x]['menu'][0]['parent_uuid'] = "bc96d773-ee57-0cdd-c3ac-2d91aba61b55";
$apps[$x]['menu'][0]['category'] = "internal";
$apps[$x]['menu'][0]['path'] = "/app/xmpp/xmpp.php";
$apps[$x]['menu'][0]['groups'][] = "superadmin";

?>