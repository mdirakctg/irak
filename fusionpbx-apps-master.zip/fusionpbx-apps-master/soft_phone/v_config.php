<?php
	/*
	//application details
		$apps[$x]['name'] = "Soft Phone";
		$apps[$x]['uuid'] = 'd49d1e25-2240-dcb3-8a40-643232472a2d';
		$apps[$x]['category'] = 'Switch';;
		$apps[$x]['subcategory'] = '';
		$apps[$x]['version'] = '';
		$apps[$x]['license'] = 'Mozilla Public License 1.1';
		$apps[$x]['url'] = 'http://www.fusionpbx.com';
		$apps[$x]['description']['en'] = 'Used with PortAudio.';
	
	//menu details	
		$apps[$x]['menu'][0]['title']['en'] = 'Soft Phone';
		$apps[$x]['menu'][0]['uuid'] = '0875598d-bf25-d348-2e87-8d05aef3cf78';
		$apps[$x]['menu'][0]['parent_uuid'] = 'fd29e39c-c936-f5fc-8e2b-611681b266b5';
		$apps[$x]['menu'][0]['category'] = 'internal';
		$apps[$x]['menu'][0]['path'] = '/app/soft_phone/v_softphone.php';
		$apps[$x]['menu'][0]['groups'][] = 'admin';
		$apps[$x]['menu'][0]['groups'][] = 'superadmin';

	//permission details
		$apps[$x]['permissions'][0]['name'] = 'soft_phone_view';
		$apps[$x]['permissions'][0]['groups'][] = 'admin';
		$apps[$x]['permissions'][0]['groups'][] = 'superadmin';

		$apps[$x]['permissions'][1]['name'] = 'soft_phone_dial';
		$apps[$x]['permissions'][1]['groups'][] = 'admin';
		$apps[$x]['permissions'][1]['groups'][] = 'superadmin';
	*/
?>