<?php

	$apps[$x]['menu'][0]['title']['en'] = 'SIP Profiles';
	$apps[$x]['menu'][0]['uuid'] = '3fe562d4-b9d2-74d2-7def-bff4707831e2';
	$apps[$x]['menu'][0]['parent_uuid'] = '594d99c5-6128-9c88-ca35-4b33392cec0f';
	$apps[$x]['menu'][0]['category'] = 'internal';
	$apps[$x]['menu'][0]['path'] = '/app/profiles/v_profiles.php';
	$apps[$x]['menu'][0]['groups'][] = 'superadmin';

?>