<?php

	$text['title-voicemail']['en-us'] = 'Voicemail';
	$text['title-voicemail']['pt-pt'] = '';

	$text['description-voicemail']['en-us'] = 'Show details about the voicemail settings including the voicemail count, and voicemail to email address.';
	$text['description-voicemail']['pt-pt'] = '';

	$text['label-extension']['en-us'] = 'Extension';
	$text['label-extension']['pt-pt'] = '';

	$text['label-voicemail']['en-us'] = 'Voicemail Mail To';
	$text['label-voicemail']['pt-pt'] = '';

	$text['label-messages']['en-us'] = 'Messages';
	$text['label-messages']['pt-pt'] = '';

	$text['label-enabled']['en-us'] = 'Enabled';
	$text['label-enabled']['pt-pt'] = '';

	$text['label-description']['en-us'] = 'Description';
	$text['label-description']['pt-pt'] = '';

	$text['label-prefs-delete']['en-us'] = 'Voicemail Preferences set to default';
	$text['label-prefs-delete']['pt-pt'] = '';

	$text['confirm-prefs-delete-alt']['en-us'] = 'restore default preferences';
	$text['confirm-prefs-delete-alt']['pt-pt'] = '';

	$text['confirm-prefs-delete-title']['en-us'] = 'restore default preferences';
	$text['confirm-prefs-delete-title']['pt-pt'] = '';

	$text['confirm-prefs-delete']['en-us'] = 'Are you sure you want to remove the voicemail name and greeting?';
	$text['confirm-prefs-delete']['pt-pt'] = '';

?>