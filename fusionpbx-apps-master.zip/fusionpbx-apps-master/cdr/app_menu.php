<?php

	$apps[$x]['menu'][0]['title']['en'] = 'CDR CSV';
	$apps[$x]['menu'][0]['uuid'] = '57d6bea3-edd3-13c8-e841-cc4cd852b905';
	$apps[$x]['menu'][0]['parent_uuid'] = 'fd29e39c-c936-f5fc-8e2b-611681b266b5';
	$apps[$x]['menu'][0]['category'] = 'internal';
	$apps[$x]['menu'][0]['path'] = '/app/cdr/v_cdr.php';
	$apps[$x]['menu'][0]['groups'][] = 'hidden';

?>