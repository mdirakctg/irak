<meta http-equiv="refresh" content="2;url=v_tickets.php">
<div align='center'>
<?php 
if ($action == "add") {
	echo "Create Complete\n";
}
if ($action == "update") {
	echo "Update Complete\n";
}
?>
</div>
