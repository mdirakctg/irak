<?php

	$apps[$x]['menu'][0]['title']['en-us'] = 'WebRTC';
	$apps[$x]['menu'][0]['uuid'] = '0044c532-07ca-477f-aa2d-920ee58e100b';
	$apps[$x]['menu'][0]['parent_uuid'] = 'fd29e39c-c936-f5fc-8e2b-611681b266b5';
	$apps[$x]['menu'][0]['category'] = 'internal';
	$apps[$x]['menu'][0]['path'] = '/app/webrtc/webrtc.php';
	$apps[$x]['menu'][0]['groups'][] = 'superadmin';

?>
