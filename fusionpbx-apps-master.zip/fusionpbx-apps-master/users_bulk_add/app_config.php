<?php
	/*
	//application details
		$apps[$x]['name'] = "zzz";
		$apps[$x]['uuid'] = 'zzz';
		$apps[$x]['category'] = '';
		$apps[$x]['subcategory'] = '';
		$apps[$x]['version'] = '';
		$apps[$x]['license'] = 'Mozilla Public License 1.1';
		$apps[$x]['url'] = 'http://www.fusionpbx.com';
		$apps[$x]['description']['en'] = 'zzz.';

	//menu details
		$apps[$x]['menu'][0]['title']['en'] = 'zzz';
		$apps[$x]['menu'][0]['uuid'] = 'zzz';
		$apps[$x]['menu'][0]['parent_uuid'] = 'zzz';
		$apps[$x]['menu'][0]['category'] = 'internal';
		$apps[$x]['menu'][0]['path'] = '/app/zzz/zzz.php';
		$apps[$x]['menu'][0]['groups'][] = 'superadmin';

	//permission details
		$apps[$x]['permissions'][0]['name'] = 'zzz';
		$apps[$x]['permissions'][0]['groups'][] = 'admin';
		$apps[$x]['permissions'][0]['groups'][] = 'superadmin';
	*/
?>