<?php

	$y=0;
	$apps[$x]['menu'][$y]['title']['en-us'] = "Languages";
	$apps[$x]['menu'][$y]['title']['ar-eg'] = "اللغات"; //Google translate
	$apps[$x]['menu'][$y]['title']['de-at'] = "Sprachen"; //Google translate
	$apps[$x]['menu'][$y]['title']['de-ch'] = "Sprachen"; //Google translate
	$apps[$x]['menu'][$y]['title']['de-de'] = "Sprachen"; //Google translate
	$apps[$x]['menu'][$y]['title']['es-cl'] = "Idiomas"; //Google translate
	$apps[$x]['menu'][$y]['title']['es-mx'] = "Idiomas"; //Google translate
	$apps[$x]['menu'][$y]['title']['fr-ca'] = "Les langues"; //Google translate
	$apps[$x]['menu'][$y]['title']['fr-fr'] = "Les langues"; //Google translate
	$apps[$x]['menu'][$y]['title']['he-il'] = "שפות"; //Google translate
	$apps[$x]['menu'][$y]['title']['it-it'] = "Le lingue"; //Google translate
	$apps[$x]['menu'][$y]['title']['nl-nl'] = "Talen"; //Google translate
	$apps[$x]['menu'][$y]['title']['pl-pl'] = "Języki"; //Google translate
	$apps[$x]['menu'][$y]['title']['pt-br'] = "línguas"; //Google translate
	$apps[$x]['menu'][$y]['title']['pt-pt'] = "línguas"; //Google translate
	$apps[$x]['menu'][$y]['title']['ro-ro'] = "Limbile"; //Google translate
	$apps[$x]['menu'][$y]['title']['ru-ru'] = "Языки"; //Google translate
	$apps[$x]['menu'][$y]['title']['sv-se'] = "språk"; //Google translate
	$apps[$x]['menu'][$y]['title']['uk-ua'] = "мови"; //Google translate
	$apps[$x]['menu'][$y]['uuid'] = "13a8fd28-6718-4ac1-8acc-0bcffbce29c3";
	$apps[$x]['menu'][$y]['parent_uuid'] = "0438b504-8613-7887-c420-c837ffb20cb1";
	$apps[$x]['menu'][$y]['category'] = "internal";
	$apps[$x]['menu'][$y]['path'] = "/app/languages/index.php";
	$apps[$x]['menu'][$y]['groups'][] = "superadmin";

?>